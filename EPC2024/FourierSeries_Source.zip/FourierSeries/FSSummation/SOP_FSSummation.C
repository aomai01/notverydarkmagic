#include "SOP_FSSummation.h"

// This is an automatically generated header file based on theDsFile, below,
// to provide SOP_FSSummationParms, an easy way to access parameter values from
// SOP_FSSummationVerb::cook with the correct type.
#include "SOP_FSSummation.proto.h"

#include <GU/GU_Detail.h>
#include <OP/OP_Operator.h>
#include <OP/OP_OperatorTable.h>
#include <PRM/PRM_Include.h>
#include <PRM/PRM_TemplateBuilder.h>
#include <UT/UT_DSOVersion.h>
#include <UT/UT_Interrupt.h>
#include <UT/UT_StringHolder.h>
#include <SYS/SYS_Math.h>
#include <limits.h>

#include <complex>  // Required by the FS project

using namespace UT::Literal;
using namespace HDK_Sample;

//
// Help is stored in a "wiki" style text file.  This text file should be copied
// to $HOUDINI_PATH/help/nodes/sop/*.txt
//
// See the sample_install.sh file for an example.
//

/// This is the internal name of the SOP type.
/// It isn't allowed to be the same as any other SOP's type name.
const UT_StringHolder SOP_FSSummation::theSOPTypeName("hdk_fs_summation"_sh);

/// newSopOperator is the hook that Houdini grabs from this dll
/// and invokes to register the SOP.  In this case, we add ourselves
/// to the specified operator table.
void
newSopOperator(OP_OperatorTable *table)
{
    table->addOperator(new OP_Operator(
        SOP_FSSummation::theSOPTypeName,   // Internal name
        "HDK Fourier Series Summation",    // UI name
        SOP_FSSummation::myConstructor,    // How to build the SOP
        SOP_FSSummation::buildTemplates(), // My parameters
        1,                                 // Min # of sources
        1,                                 // Max # of sources
        nullptr));                         // Custom local variables (none)
}

/// This is a multi-line raw string specifying the parameter interface
/// for this SOP.
static const char *theDsFile = R"THEDSFILE(
{
    name        parameters 
    parm {
        name    "time"      // Internal parameter name
        label   "Time"      // Descriptive parameter name for user interface
        type    float
        default { "$FF" }   // Default for this parameter on new nodes
        range   { 0 1000 }  // The value range. A "!" suffix means a hard limit.
        export  all         // This makes the parameter show up in the toolbox
                            // above the viewport when it's in the node's state.
    }
    parm {
        name    "speed"
        label   "Speed"
        type    float
        default { "0.001" }
        range   { 0 0.1 }
        export  all
    }
}
)THEDSFILE";

PRM_Template*
SOP_FSSummation::buildTemplates()
{
    static PRM_TemplateBuilder templ("SOP_FSSummation.C"_sh, theDsFile);
    return templ.templates();
}

class SOP_FSSummationVerb : public SOP_NodeVerb
{
public:
    SOP_FSSummationVerb() {}
    virtual ~SOP_FSSummationVerb() {}

    virtual SOP_NodeParms *allocParms() const { return new SOP_FSSummationParms(); }
    virtual UT_StringHolder name() const { return SOP_FSSummation::theSOPTypeName; }

    virtual CookMode cookMode(const SOP_NodeParms *parms) const { return COOK_INPLACE; }

    virtual void cook(const CookParms &cookparms) const;
    
    /// This static data member automatically registers
    /// this verb class at library load time.
    static const SOP_NodeVerb::Register<SOP_FSSummationVerb> theVerb;
};

// The static member variable definition has to be outside the class definition.
// The declaration is inside the class.
const SOP_NodeVerb::Register<SOP_FSSummationVerb> SOP_FSSummationVerb::theVerb;

const SOP_NodeVerb *
SOP_FSSummation::cookVerb() const 
{ 
    return SOP_FSSummationVerb::theVerb.get();
}

const UT_ComplexD
SOP_FSSummation::computeTerm(const UT_ComplexD coefficient, const exint n, const fpreal64 t)
{
	const std::complex<double> i(0.0, 1.0);
	const std::complex<double> eix = std::exp(2.0 * static_cast<double>(n) * M_PI * i * t);
	const UT_ComplexD complexExp(eix.real(), eix.imag());

	return coefficient.operator*(complexExp);
}

/// This is the function that does the actual work.
void
SOP_FSSummationVerb::cook(const SOP_NodeVerb::CookParms &cookparms) const
{
    auto &&sopparms = cookparms.parms<SOP_FSSummationParms>();
    GU_Detail *detail = cookparms.gdh().gdpNC();

    exint npoints = detail->getNumPoints();

    // If this SOP has cooked before and it wasn't evicted from the cache,
    // its output detail will contain the geometry from the last cook.
    // If it hasn't cooked, or if it was evicted from the cache,
    // the output detail will be empty.
    // This knowledge can save us some effort, e.g. if the number of points on
    // this cook is the same as on the last cook, we can just move the points,
    // (i.e. modifying P), which can also save some effort for the viewport.

    GA_Offset start_ptoff;
    // Same number of points as last cook, and we know that last time,
    // we created a contiguous block of point offsets, so just get the
    // first one.
    start_ptoff = detail->pointOffset(GA_Index(0));

    // We'll only be modifying P, so we only need to bump P's data ID.
    detail->getP()->bumpDataId();

    // Everything after this is just to figure out what to write to P and write it.

    // Start the interrupt scope
    UT_AutoInterrupt boss("Summing up the Fourier Series");
    if (boss.wasInterrupted())
        return;

	UT_ComplexD term_origin(0.0, 0.0);
	fpreal64 t = sopparms.getTime() * sopparms.getSpeed();

	GA_RWHandleV3 attrib_N(detail->addFloatTuple(GA_ATTRIB_POINT, "N", 3));
	GA_RWHandleV3 attrib_up(detail->addFloatTuple(GA_ATTRIB_POINT, "up", 3));
	GA_RWHandleF attrib_scale(detail->addFloatTuple(GA_ATTRIB_POINT, "pscale", 1));

    GA_ROHandleV3D attrib_coeff(detail->findPointAttribute("coefficient"));
    GA_ROHandleI attrib_index(detail->findPointAttribute("term_index"));
    
    for (exint n = 0; n < npoints; ++n)
    {
        // Check to see if the user has interrupted us...
        if (boss.wasInterrupted())
            break;

		GA_Offset ptoff = detail->pointOffset(n);

        UT_Vector3D coefficient_encoded = attrib_coeff.get(ptoff);
		UT_ComplexD coefficient(coefficient_encoded.x(), coefficient_encoded.y());
		exint term_index = static_cast<exint>(attrib_index.get(ptoff));

		UT_ComplexD term_landing = term_origin.operator+(SOP_FSSummation::computeTerm(coefficient, term_index, t));
		

		fpreal x = term_landing.real();
		fpreal y = term_landing.imaginary();
		fpreal z = 0.0;

		UT_Vector3R pos(x, y, z);
        detail->setPos3(ptoff, pos);
		
		UT_Vector3 normal(term_landing.real() - term_origin.real(), term_landing.imaginary() - term_origin.imaginary(), 0.0);
		normal.normalize();
		attrib_N.set(ptoff, normal);

		UT_Vector3 up(0.0f, 1.0f, 0.0f);
		attrib_up.set(ptoff, up);

		fpreal32 scale = coefficient_encoded.z();
		attrib_scale.set(ptoff, scale);

		term_origin = term_landing;
    }

    attrib_N.bumpDataId();
    attrib_up.bumpDataId();
    attrib_scale.bumpDataId();
}

#include "SOP_FSCoefficients.h"

// This is an automatically generated header file based on theDsFile, below,
// to provide SOP_FSCoefficientsParms, an easy way to access parameter values from
// SOP_FSCoefficientsVerb::cook with the correct type.
#include "SOP_FSCoefficients.proto.h"

#include <GU/GU_Detail.h>
#include <OP/OP_Operator.h>
#include <OP/OP_OperatorTable.h>
#include <PRM/PRM_Include.h>
#include <PRM/PRM_TemplateBuilder.h>
#include <UT/UT_DSOVersion.h>
#include <UT/UT_Interrupt.h>
#include <UT/UT_StringHolder.h>
#include <SYS/SYS_Math.h>
#include <limits.h>

#include <complex>  // Required by the FS project

using namespace UT::Literal;
using namespace HDK_Sample;

//
// Help is stored in a "wiki" style text file.  This text file should be copied
// to $HOUDINI_PATH/help/nodes/sop/*.txt
//
// See the sample_install.sh file for an example.
//

/// This is the internal name of the SOP type.
/// It isn't allowed to be the same as any other SOP's type name.
const UT_StringHolder SOP_FSCoefficients::theSOPTypeName("hdk_fs_coefficients"_sh);

/// newSopOperator is the hook that Houdini grabs from this dll
/// and invokes to register the SOP.  In this case, we add ourselves
/// to the specified operator table.
void
newSopOperator(OP_OperatorTable *table)
{
    table->addOperator(new OP_Operator(
        SOP_FSCoefficients::theSOPTypeName,   // Internal name
        "HDK Fourier Series Coefficients",    // UI name
        SOP_FSCoefficients::myConstructor,    // How to build the SOP
        SOP_FSCoefficients::buildTemplates(), // My parameters
        1,                                    // Min # of sources
        1,                                    // Max # of sources
        nullptr,                              // Custom local variables (none)
        OP_FLAG_GENERATOR));                  // Flag it as generator
}

/// This is a multi-line raw string specifying the parameter interface
/// for this SOP.
static const char *theDsFile = R"THEDSFILE(
{
    name        parameters 
    parm {
        name    "terms"           // Internal parameter name
        label   "Terms"           // Descriptive parameter name for user interface
        type    integer
        default { "npoints(0)" }  // Default for this parameter on new nodes
        range   { 2! 2000 }       // The value range. A "!" suffix means a hard limit.
        export  all               // This makes the parameter show up in the toolbox
                                  // above the viewport when it's in the node's state.
    }
}
)THEDSFILE";

PRM_Template*
SOP_FSCoefficients::buildTemplates()
{
    static PRM_TemplateBuilder templ("SOP_FSCoefficients.C"_sh, theDsFile);
    return templ.templates();
}

class SOP_FSCoefficientsVerb : public SOP_NodeVerb
{
public:
    SOP_FSCoefficientsVerb() {}
    virtual ~SOP_FSCoefficientsVerb() {}

    virtual SOP_NodeParms *allocParms() const { return new SOP_FSCoefficientsParms(); }
    virtual UT_StringHolder name() const { return SOP_FSCoefficients::theSOPTypeName; }

    virtual CookMode cookMode(const SOP_NodeParms *parms) const { return COOK_GENERATOR; }

    virtual void cook(const CookParms &cookparms) const;
    
    /// This static data member automatically registers
    /// this verb class at library load time.
    static const SOP_NodeVerb::Register<SOP_FSCoefficientsVerb> theVerb;
};

// The static member variable definition has to be outside the class definition.
// The declaration is inside the class.
const SOP_NodeVerb::Register<SOP_FSCoefficientsVerb> SOP_FSCoefficientsVerb::theVerb;

const SOP_NodeVerb *
SOP_FSCoefficients::cookVerb() const 
{ 
    return SOP_FSCoefficientsVerb::theVerb.get();
}

const UT_ComplexD
SOP_FSCoefficients::coefficientIntegralStep(const UT_ComplexD pos_t, const exint n, const fpreal64 t, const fpreal64 dt)
{
	const std::complex<double> i(0.0, 1.0);
	const std::complex<double> eix = std::exp(-2.0 * static_cast<double>(n) * M_PI * i * t);
	const UT_ComplexD complexExp(eix.real(), eix.imag());

	return pos_t.operator*(complexExp).operator*(dt);
}

/// This is the function that does the actual work.
void
SOP_FSCoefficientsVerb::cook(const SOP_NodeVerb::CookParms &cookparms) const
{
    auto &&sopparms = cookparms.parms<SOP_FSCoefficientsParms>();
    GU_Detail *detail = cookparms.gdh().gdpNC();

	const GEO_Detail * sample_geo = cookparms.inputGeo(0);
	const exint sample_npoints = sample_geo->getNumPoints();

    exint npoints = sopparms.getTerms();

    if (npoints < 2)
    {
        // With the range restriction we have on the divisions, this
        // is actually impossible, (except via integer overflow),
        // but it shows how to add an error message or warning to the SOP.
        cookparms.sopAddError(SOP_MESSAGE, "There must be at least 2 terms.");
        npoints = 2;
    }

    // If this SOP has cooked before and it wasn't evicted from the cache,
    // its output detail will contain the geometry from the last cook.
    // If it hasn't cooked, or if it was evicted from the cache,
    // the output detail will be empty.
    // This knowledge can save us some effort, e.g. if the number of points on
    // this cook is the same as on the last cook, we can just move the points,
    // (i.e. modifying P), which can also save some effort for the viewport.

    GA_Offset start_ptoff;
    if (detail->getNumPoints() != npoints)
    {
        // Either the SOP hasn't cooked, the detail was evicted from
        // the cache, or the number of points changed since the last cook.

        // This destroys everything except the empty P and topology attributes.
        detail->clearAndDestroy();

        // Create the right number of points, as a contiguous block
        // of point offsets.
        start_ptoff = detail->appendPointBlock(npoints);

        // We added points, vertices, and primitives,
        // so this will bump all topology attribute data IDs,
        // P's data ID, and the primitive list data ID.
        detail->bumpDataIdsForAddOrRemove(true, false, false);
    }
    else
    {
        // Same number of points as last cook, and we know that last time,
        // we created a contiguous block of point offsets, so just get the
        // first one.
        start_ptoff = detail->pointOffset(GA_Index(0));

        // We'll only be modifying P, so we only need to bump P's data ID.
        detail->getP()->bumpDataId();
    }

    // Everything after this is just to figure out what to write to P and write it.

    // Start the interrupt scope
    UT_AutoInterrupt boss("Computing the Fourier Series coefficients");
    if (boss.wasInterrupted())
        return;

	fpreal64 dt = 1.0 / static_cast<fpreal64>(sample_npoints);

    GA_RWHandleI term_index(detail->addIntTuple(GA_ATTRIB_POINT, "term_index", 1));

    // DEBUG: Try creating `coefficient` using this
    //GA_RWHandleV3D coefficient_encoded(detail->addFloatTuple(GA_ATTRIB_POINT, "coefficient", 3));
    
    GA_RWHandleV3D coefficient_encoded(detail->addFloatTuple(GA_ATTRIB_POINT, "coefficient", 3, GA_Defaults(0.0), 0, 0, GA_STORE_REAL64));
    
    // DEBUG: Optionally add this line
    coefficient_encoded.getAttribute()->setTypeInfo(GA_TYPE_VOID);
    

    // Numerically integrates the coefficient for every term
    for (exint n = 0; n < npoints; ++n)
    {
        // Check to see if the user has interrupted us...
        if (boss.wasInterrupted())
            break;

		UT_ComplexD coefficient(0.0, 0.0);
		exint n_remapped = static_cast<exint>(SYSrint(0.5f * static_cast<float>(n)) * static_cast<float>(-1 + 2 * (n % 2)));

        // Numerically integrates the coefficient for term n
		for (exint sample_pt = 0; sample_pt < sample_npoints; ++sample_pt)
		{
			GA_Offset sample_ptoff = sample_geo->pointOffset(sample_pt);
			UT_Vector3D sample_pos = sample_geo->getPos3(sample_ptoff);  // DEBUG: Try using `sample_pt` here
			UT_ComplexD pos_t(sample_pos.x(), sample_pos.y());
			fpreal64 t = dt * static_cast<fpreal64>(sample_pt);

			coefficient = coefficient.operator+(SOP_FSCoefficients::coefficientIntegralStep(pos_t, n_remapped, t, dt));
		}

		fpreal x = coefficient.real();
		fpreal y = coefficient.imaginary();
        fpreal z = coefficient.magnitude();
		
        // Since we created a contiguous block of point offsets,
        // we can just add i to start_ptoff to find this point offset.
        GA_Offset ptoff = start_ptoff + n;
        detail->setPos3(ptoff, UT_Vector3(n, 0.0, 0.0));
        coefficient_encoded.set(ptoff, UT_Vector3D(x, y, z));
        term_index.set(ptoff, n_remapped);
    }

    // DEBUG: Try skipping this part
    coefficient_encoded.bumpDataId();
    term_index.bumpDataId();
}

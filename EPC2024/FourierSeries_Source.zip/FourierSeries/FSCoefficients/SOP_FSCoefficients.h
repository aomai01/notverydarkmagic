#ifndef __SOP_FSCoefficients_h__
#define __SOP_FSCoefficients_h__

#include <SOP/SOP_Node.h>
#include <UT/UT_StringHolder.h>

#include <UT/UT_Complex.h>  // Required by the FS project

namespace HDK_Sample {
/// This is the SOP class definition.  It doesn't need to be in a separate
/// file like this.  This is just an example of a header file, in case
/// another file needs to reference something in here.
/// You shouldn't have to change anything in here except the name of the class.
class SOP_FSCoefficients : public SOP_Node
{
public:
    static PRM_Template *buildTemplates();
    static OP_Node *myConstructor(OP_Network *net, const char *name, OP_Operator *op)
    {
        return new SOP_FSCoefficients(net, name, op);
    }

    static const UT_StringHolder theSOPTypeName;
    
    const SOP_NodeVerb *cookVerb() const override;

	static const UT_ComplexD coefficientIntegralStep(const UT_ComplexD pos_t, const exint n, const fpreal64 t, const fpreal64 dt);

protected:
    SOP_FSCoefficients(OP_Network *net, const char *name, OP_Operator *op)
        : SOP_Node(net, name, op)
    {
        // All verb SOPs must manage data IDs, to track what's changed
        // from cook to cook.
        mySopFlags.setManagesDataIDs(true);
    }
    
    ~SOP_FSCoefficients() override {}

    /// Since this SOP implements a verb, cookMySop just delegates to the verb.
    OP_ERROR cookMySop(OP_Context &context) override
    {
        return cookMyselfAsVerb(context);
    }
};
} // End HDK_Sample namespace

#endif
